import bpy
import os
import shutil
from bpy.types import Operator, Menu
from . _addpresetbase import AddPresetBase


class DefaultPresets:
    """ Copy default presets to user preset directory"""

    def __init__(self):
        user_presets = bpy.utils.user_resource('SCRIPTS', path="presets/physical-addons/psa", create=True)
        default_presets = bpy.utils.user_resource('SCRIPTS', path="addons/physical-starlight-atmosphere/presets")
        files = os.listdir(default_presets)
        path = os.path
        for file in files:
            if not path.isfile(path.join(user_presets, file)):
                shutil.copy2(path.join(default_presets, file), user_presets)


class RIG_MT_Presets(Menu):
    bl_label = "· Earth"  # Kind a workaround to show the default preset
    preset_subdir = "physical-addons/psa"
    preset_operator = "script.execute_preset"
    draw = Menu.draw_preset


class RIG_OT_AddPreset(AddPresetBase, Operator):
    bl_idname = "world.atmosphere_add_preset"
    bl_label = "Add Preset"
    preset_menu = "RIG_MT_Presets"
    preset_subdir = "physical-addons/psa"  # where to store the preset
    preset_defines = [
        "s = bpy.context.scene.atmosphere_settings"
    ]

    @property
    def preset_values(self):
        preset_values = [
            "s.sun_disk",
            "s.sun_lamp",
            "s.sun_diameter",
            "s.sun_temperature",
            "s.sun_intensity",

            "s.atmosphere_density",
            "s.atmosphere_height",
            "s.atmosphere_intensity",
            "s.atmosphere_color",
            "s.atmosphere_inscattering",
            "s.atmosphere_extinction",
            "s.atmosphere_mie",
            "s.atmosphere_mie_dir",
            "s.night_intensity",

            "s.stars_type",
            "s.stars_path",
            "s.stars_intensity",
            "s.stars_gamma",
            
            "s.ground_visible",
            "s.ground_albedo",
            "s.ground_offset",
            "s.horizon_offset",

            "s.atmosphere_distance",
            "s.atmosphere_falloff",
            "s.sun_radiance_gamma",

            "s.preset_name",
            "s.preset_filename",
        ]
        prefs = bpy.context.preferences.addons['physical-starlight-atmosphere'].preferences
        if hasattr(bpy.context, 'scene'):
            gsettings = bpy.context.scene.general_settings
            asettings = bpy.context.scene.atmosphere_settings
        if gsettings.include_sunpos:
            preset_values.insert(0, "s.azimuth")
            preset_values.insert(0, "s.elevation")
        if prefs.use_experimental_features:
            preset_values.insert(0, "s.enable_binary_sun")
        if prefs.use_experimental_features and asettings.enable_binary_sun:
            preset_values.insert(0, "s.binary_distance")
            preset_values.insert(0, "s.binary_phase")
            preset_values.insert(0, "s.binary_diameter")
            preset_values.insert(0, "s.binary_temperature")
            preset_values.insert(0, "s.binary_intensity")
        return preset_values
