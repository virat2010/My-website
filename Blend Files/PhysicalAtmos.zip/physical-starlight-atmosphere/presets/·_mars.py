import bpy
s = bpy.context.scene.atmosphere_settings

s.sun_diameter = 0.006108652334660292
s.sun_temperature = 5700.0
s.sun_intensity = 200000.0
s.atmosphere_density = 0.3964160084724426
s.atmosphere_height = 700.0
s.atmosphere_intensity = 3.0
s.atmosphere_color = (0.746660053730011, 0.5966405272483826, 0.3081672191619873, 1.0)
s.atmosphere_inscattering = (0.8599934577941895, 0.7776269316673279, 0.6236038208007812, 1.0)
s.atmosphere_extinction = (0.7115856409072876, 0.7946324944496155, 0.8266600966453552, 1.0)
s.atmosphere_mie = 4.0
s.atmosphere_mie_dir = 0.8495832681655884
s.night_intensity = 0.019999999552965164
s.stars_type = 'procedural'
s.stars_path = ''
s.stars_intensity = 0.11999999731779099
s.stars_gamma = 0.5
s.ground_albedo = (0.7666598558425903, 0.3285926580429077, 0.12984487414360046, 1.0)
s.ground_offset = -1.0
s.atmosphere_distance = 1.0
s.atmosphere_falloff = 1.0
s.sun_radiance_gamma = 1.0
s.preset_name = 'mars'
s.preset_filename = '·_mars.py'