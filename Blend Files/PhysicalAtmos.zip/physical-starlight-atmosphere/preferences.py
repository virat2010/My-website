import bpy
from bpy.props import *
from . ui import *  # RIG_PT_StarlightAtmosphere


def update_toolbar_label(self, context):
    classes = [
        RIG_PT_StarlightAtmosphereTB,
        RIG_PT_SunTB,
        RIG_PT_BinarySunTB,
        RIG_PT_AtmosphereTB,
        RIG_PT_StarsTB,
        RIG_PT_GroundTB,
        RIG_PT_ArtisticControlsTB,
    ]

    panel_exists = hasattr(bpy.types, 'RIG_PT_StarlightAtmosphereTB')
    if panel_exists:
        for cls in classes:
            bpy.utils.unregister_class(cls)

    # Set Toolbar Label
    RIG_PT_StarlightAtmosphereTB.bl_category = self.toolbar_label
    for cls in classes:
        bpy.utils.register_class(cls)


def toggle_physical_values(self, context):
    addon_prefs = context.preferences.addons['physical-starlight-atmosphere'].preferences
    gsettings = context.scene.general_settings
    if addon_prefs.use_physical_values:
        gsettings.intensity_multiplier = 100
    else:
        gsettings.intensity_multiplier = 1
    if gsettings.enabled:
        depsgraph = bpy.context.evaluated_depsgraph_get()
        sun_calculation(bpy.context, depsgraph, 'realtime')  # redraw


class RIG_OT_OpenExpFeaturesPage(bpy.types.Operator):
    bl_idname = 'rig.open_exp_features_page'
    bl_label = 'Feature List'
    bl_options = {'REGISTER', 'INTERNAL'}
    bl_description = "Read about Experimental Features in documentation"

    def execute(self, context):
        bpy.ops.wm.url_open(url='https://www.physicaladdons.com/psa/customization/#experimental-features')
        return {'FINISHED'}


class RIG_MT_addon_preferences(bpy.types.AddonPreferences):
    bl_idname = "physical-starlight-atmosphere"  # __name__ would be physical-starlight-atmosphere.preferences

    use_physical_values: bpy.props.BoolProperty(
        default=False,
        description="Use real world physical values",
        update=toggle_physical_values
    )

    use_experimental_features: bpy.props.BoolProperty(
        default=True,
        description="Use experimental features",
    )

    toolbar_enabled: bpy.props.BoolProperty(
        default=True,
        description="Toggle Toolbar (N panel)",
    )

    toolbar_label: StringProperty(
        description="Choose addon name for the Toolbar (N panel)",
        default="Atmosphere",
        update=update_toolbar_label
    )

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        col = box.column()
        col.prop(self, "use_physical_values", text="Use real world physical values")
        col.prop(self, "toolbar_enabled", text="Toolbar enabled")
        col.label(text="Toolbar label:")
        row = col.split(factor=0.5, align=True)
        row.prop(self, "toolbar_label", text="")

        box = layout.box()
        col = box.column()
        col.alert = True
        col.scale_y = 0.8
        col.label(
            text="Experimental features may not be fully functional and tested for all cases",
            icon="ERROR"
        )

        row = box.row(align=True)
        labelColumn = row.column(align=True)
        labelColumn.prop(self, "use_experimental_features", text="Experimental Features")

        operatorColumn = row.column(align=True)
        operatorColumn.alignment = "RIGHT"
        operatorColumn.operator(RIG_OT_OpenExpFeaturesPage.bl_idname, icon='URL')
