import bpy
from bpy.types import PropertyGroup
from bpy.props import (
    BoolProperty,
    FloatProperty,
    FloatVectorProperty,
    EnumProperty,
    IntProperty,
    StringProperty,
    PointerProperty,
)
from . handlers import *
from . clouds import toggle_clouds, clouds_update_handler


def set_current_values_as_defaults(self, context):
    """Dynamically re-initialize atmosphere settings with new default values"""
    # print(self.preset_name)
    updated_properties = update_atmosphere_settings()  # set new values for the properties
    dattributes = {}
    for property in updated_properties:
        propType = property["type"]
        propName = property["name"]
        if propType == "bool":
            dattributes[propName] = bpy.props.BoolProperty(**property["attributes"])
        elif propType == "int":
            dattributes[propName] = bpy.props.IntProperty(**property["attributes"])
        elif propType == "string":
            dattributes[propName] = bpy.props.StringProperty(**property["attributes"])
        elif propType == "float":
            dattributes[propName] = bpy.props.FloatProperty(**property["attributes"])
        elif propType == "floatvector":
            dattributes[propName] = bpy.props.FloatVectorProperty(**property["attributes"])
        elif propType == "enum":
            dattributes[propName] = bpy.props.EnumProperty(**property["attributes"])

    DynamicProperties = type('DynamicProperties', (PropertyGroup,), {'__annotations__': dattributes})
    bpy.utils.register_class(DynamicProperties)
    bpy.types.Scene.atmosphere_settings = PointerProperty(type=DynamicProperties)


class GeneralSettings(PropertyGroup):
    ############################################################################
    # General Properties
    ############################################################################

    enabled: BoolProperty(
        name="Enable atmosphere",
        default=False,
        update=enable_atmosphere
    )

    initialized: BoolProperty(
        name="Init",
        default=False,
    )

    material_count: IntProperty(
        name="Material Count",
        default=0,
    )

    intensity_multiplier: IntProperty(
        name="Default property intensity multiplier",
        default=1,
    )

    sun_pos_checksum: FloatProperty(
        name="Sun Position checksum",
        default=0,
    )

    all_props_checksum: StringProperty(
        description="Contains last frame all property string concatenation",
    )

    fog_enabled: BoolProperty(
        default=False
    )

    silent_update: BoolProperty(
        default=False,
        description="Update azimuth or elevation without triggering update function"
    )

    include_sunpos: BoolProperty(
        name="Include Sun Position",
        description="Save azimuth and elevation in the preset",
        default=True
    )

    # All cloud related properties
    clouds_enabled: BoolProperty(
        name="Enable clouds",
        default=False,
        update=toggle_clouds
    )

    clouds_scale : FloatProperty(
        name = "Scale",
        description = "Clouds scale",
        min = 0,
        soft_max = 10,
        step = 0.1,
        precision = 2,
        default = 1,
        unit = "NONE",
        subtype = "FACTOR",
        update = clouds_update_handler,
    )

    clouds_min : FloatProperty(
        name = "Min",
        description = "Clouds min",
        min = -1,
        soft_max = 1,
        step = 0.1,
        precision = 2,
        default = -0.5,
        unit = "NONE",
        subtype = "FACTOR",
        update = clouds_update_handler,
    )

    clouds_max : FloatProperty(
        name = "Max",
        description = "Clouds max",
        min = -1,
        soft_max = 1,
        step = 0.1,
        precision = 2,
        default = 0.5,
        unit = "NONE",
        subtype = "FACTOR",
        update = clouds_update_handler,
    )

    clouds_thickness : FloatProperty(
        name = "Thickness",
        description = "Clouds thickness",
        min = 0,
        soft_max = 10,
        step = 0.1,
        precision = 2,
        default = 100,
        unit = "NONE",
        subtype = "FACTOR",
        update = clouds_update_handler,
    )

    clouds_scattering : FloatVectorProperty(
        name = "",
        description = "Clouds Inscattering",
        subtype="COLOR_GAMMA",
        size=4,
        min=0.0,
        max=1.0,
        default=(0.4, 0.45, 0.8, 1.0),
        update = clouds_update_handler
    )

    clouds_amount : FloatProperty(
        name = "Self Shadowing",
        description = "Self Shadowing",
        min = 0,
        soft_max = 100,
        step = 0.1,
        precision = 2,
        default = 10,
        unit = "NONE",
        subtype = "FACTOR",
        update = clouds_update_handler,
    )

    clouds_power : FloatProperty(
        name = "Directional Power",
        description = "Clouds power",
        min = 0,
        soft_max = 100,
        step = 0.1,
        precision = 2,
        default = 5,
        unit = "NONE",
        subtype = "FACTOR",
        update = clouds_update_handler,
    )

    clouds_lighting_intensity : FloatProperty(
    name = "Lighting Intensity",
    description = "Lighting Intensity",
    min = 0,
    soft_max = 10,
    step = 1,
    precision = 2,
    default = 1,
    unit = "NONE",
    subtype = "FACTOR",
    update = clouds_update_handler,
    )


class AtmosphereSettings(PropertyGroup):
    ############################################################################
    # Physical Atmosphere panel properties
    ############################################################################
    preset_filename: StringProperty(
        description="Toggles Sun disk in the atmosphere",
        default='·_earth.py'
    )

    preset_name: StringProperty(
        update=set_current_values_as_defaults,
    )

    sun_disk : BoolProperty(
        name = "Sun Disk",
        description = "Toggles Sun disk in the atmosphere",
        default = True,
        update = sun_calculation_handler
    )

    sun_lamp : BoolProperty(
        name = "Sun Lamp",
        description = "Use Sun lamp as light source instead of Sun disk in world background",
        default = True,
        update = sun_calculation_handler
    )

    azimuth : FloatProperty(
        name = "Azimuth",
        description = "Horizontal direction: at 0° the Sun is in the Y+ axis",
        soft_min = -999,
        soft_max = 999,
        step = 5,
        precision = 3,
        default = 2.356596,
        unit = "ROTATION",
        update = azimuth_handler
    )

    elevation : FloatProperty(
        name = "Elevation",
        description = "Vertical direction: at 90° the Sun is in the zenith",
        soft_min = -999,
        soft_max = 999,
        step = 5,
        precision = 3,
        default = 3.136,
        unit = "ROTATION",
        update = elevation_handler
    )

    sun_diameter : FloatProperty(
        name = "Angular Diameter",
        description = "Angular diameter of the Sun disk in degrees",
        min = 0.001,
        max = math.pi*0.5,
        step = 1,
        precision = 3,
        default = 0.009180,
        unit = "ROTATION",
        #subtype = "ANGLE",
        update = sun_calculation_handler
    )

    atmosphere_color : FloatVectorProperty(
        name = "",
        description = "Atmosphere color",
        subtype="COLOR_GAMMA",
        size=4,
        min=0.0,
        max=1.0,
        default=(0.75, 0.8, 1.0, 1.0),
        update = sun_calculation_handler
    )

    atmosphere_inscattering : FloatVectorProperty(
        name = "",
        description = "Rayleigh scattering",
        subtype="COLOR_GAMMA",
        size=4,
        min=0.0,
        max=1.0,
        default=(0.0573, 0.1001, 0.1971, 1.000000),
        update = sun_calculation_handler
    )

    atmosphere_extinction : FloatVectorProperty(
        name = "",
        description = "Atmosphere absorption / color wavelength extinction value",
        subtype="COLOR_GAMMA",
        size=4,
        min=0.0,
        max=1.0,
        default=(1.0-0.0573, 1.0-0.1001, 1.0-0.1971, 1.000000),
        update = sun_calculation_handler
    )

    atmosphere_density : FloatProperty(
        name = "Density",
        description = "Atmosphere density in kg/m3",
        min = 0,
        soft_max = 100,
        step = 100,
        precision = 2,
        default = 1.2,
        unit = "NONE",
        subtype = "FACTOR",
        update = sun_calculation_handler
    )

    atmosphere_height : FloatProperty(
        name = "Scale Height",
        description = "Atmosphere height",
        min = 2,
        soft_max = 10000,
        step = 100,
        precision = 2,
        default = 12000,
        unit = "LENGTH",
        subtype = "DISTANCE",
        update = sun_calculation_handler
    )

    atmosphere_intensity : FloatProperty(
        name = "Intensity",
        description = "Atmosphere Radiance Intensity in W/m2",
        min = 0,
        soft_max = 500,
        step = 100,
        precision = 2,
        default = 1,
        unit = "NONE",
        subtype = "FACTOR",
        update = sun_calculation_handler
    )

    night_intensity : FloatProperty(
        name = "Night Intensity",
        description = "Night Sky Radiance Intensity in W/m2",
        min = 0.000001,
        soft_max = 0.04,
        step = 100,
        precision = 2,
        default = 0.02,
        unit = "NONE",
        subtype = "FACTOR",
        update = sun_calculation_handler
    )

    atmosphere_falloff : FloatProperty(
        name = "Falloff",
        description = "Artistic atmosphere falloff curve",
        min = 0,
        max = 3.0,
        step = 10,
        precision = 2,
        default = 1.0,
        unit = "NONE",
        subtype = "FACTOR",
        update = sun_calculation_handler
    )

    atmosphere_mie : FloatProperty(
        name = "Intensity",
        description = "Mie scattering Intensity in W/m2",
        min = 0,
        soft_max = 500.0,
        step = 10,
        precision = 2,
        default = 3.0,
        unit = "NONE",
        subtype = "FACTOR",
        update = sun_calculation_handler
    )

    atmosphere_mie_dir : FloatProperty(
        name = "Anisotropy",
        description = "Mie directional anisotropy",
        min = 0,
        max = 1.0,
        step = 10,
        precision = 2,
        default = 0.7,
        unit = "NONE",
        subtype = "FACTOR",
        update = sun_calculation_handler
    )

    atmosphere_distance : FloatProperty(
        name = "Distance Scalar",
        description = "Artistic atmosphere distance scalar",
        min = 0.0,
        soft_max = 500,
        step = 10,
        precision = 2,
        default = 1,
        unit = "NONE",
        subtype = "FACTOR",
        update = sun_calculation_handler
    )

    ground_visible: BoolProperty(
        name="Ground",
        description="Parametric ground visibility",
        default=True,
        update=sun_calculation_handler
    )

    ground_albedo : FloatVectorProperty(
        name = "",
        description = "Ground color",
        subtype ="COLOR_GAMMA",
        size = 4,
        min = 0.0,
        max = 1.0,
        default = (0.30, 0.30, 0.30, 1.0),
        update = sun_calculation_handler
    )

    ground_offset : FloatProperty(
        name = "Ground Offset",
        description = "Parametric ground plane offset distance in meters",
        unit = "LENGTH",
        subtype = "DISTANCE",
        soft_min = -500000.0,
        soft_max = 0.0,
        default = -100.0,
        update = sun_calculation_handler
    )

    horizon_offset : FloatProperty(
        name = "Horizon Offset",
        description = "Move horizon line up or down",
        unit = "NONE",
        subtype = "FACTOR",
        min = -1.0,
        max = 1.0,
        default = 0,
        update = sun_calculation_handler
    )

    sun_temperature : FloatProperty(
        name = "Temperature K",
        description = "Sun's blackbody temperature in Kelvins",
        min = 1000,
        soft_max = 10000,
        step = 100,
        precision = 2,
        default = 5700,
        unit = "NONE",
        subtype = "FACTOR",
        update = sun_calculation_handler
    )

    sun_intensity : FloatProperty(
        name = "Intensity",
        description = "Sun Radiance Intensity in W/m2. Influences only sun disk and ground",
        soft_min = 100,
        soft_max = 200000,
        step = 100,
        precision = 2,
        default = 200000,
        unit = "NONE",
        subtype = "FACTOR",
        update = sun_calculation_handler
    )

    enable_binary_sun: BoolProperty(
        name="Binary Sun",
        description="Use Binary Sun",
        default=False,
        update=sun_calculation_handler
    )

    binary_distance: FloatProperty(
        name="Distance",
        description="Distance from the Sun",
        min=0.0,
        soft_max=1,
        step=0.001,
        precision=3,
        default=0.16,
        unit="NONE",
        subtype="FACTOR",
        update=sun_calculation_handler
    )

    binary_phase: FloatProperty(
        name="Phase",
        description="Phase in context of Sun",
        soft_min=-360,
        soft_max=360,
        step=5,
        precision=3,
        default=2.0,
        unit="ROTATION",
        update=sun_calculation_handler
    )

    binary_diameter: FloatProperty(
        name="Angular Diameter",
        description="Angular diameter of the Binary Sun disk in degrees",
        min=0.001,
        max=math.pi*0.5,
        step=1,
        precision=3,
        default=0.017453,
        unit="ROTATION",
        update=sun_calculation_handler
    )

    binary_temperature: FloatProperty(
        name="Temperature K",
        description="Binary Sun's blackbody temperature in Kelvins",
        min=1000,
        soft_max=10000,
        step=100,
        precision=2,
        default=1800,
        unit="NONE",
        subtype="FACTOR",
        update=sun_calculation_handler
    )

    binary_intensity: FloatProperty(
        name="Intensity",
        description="Binary Sun Radiance Intensity in W/m2. Influences only sun disk and ground",
        soft_min=100,
        soft_max=200000,
        step=100,
        precision=2,
        default=50000,
        unit="NONE",
        subtype="FACTOR",
        update=sun_calculation_handler
    )

    sun_radiance_gamma : FloatProperty(
        name = "Sun Radiance Gamma",
        description = "Artistic Sun Radiance Gamma",
        min = 0.01,
        max = 3.0,
        step = 10,
        precision = 2,
        default = 1.0,
        unit = "NONE",
        subtype = "FACTOR",
        update = sun_calculation_handler
    )

    stars_type: EnumProperty(
        items=[('procedural', 'Procedural', 'Enable procedurally generated stars (textures loading instantly)'),
               ('texture', 'Texture', 'Enable texture for the starmap (textures loading slowly)'),
               ('none', 'None', 'disable stars')],
        default='procedural',
        update=stars_handler
    )

    stars_path : StringProperty(
        name = "Starmap File",
        description="Choose a Starmap Image File",
        subtype='FILE_PATH',
        update = stars_texture_handler,
    )

    stars_intensity : FloatProperty(
        name = "Radiance Intensity",
        description = "Stars Radiance Intensity",
        min = 0,
        soft_max = 15.0,
        step = 10,
        precision = 2,
        default = 0.5,
        unit = "NONE",
        subtype = "FACTOR",
        update = sun_calculation_handler
    )

    stars_gamma : FloatProperty(
        name = "Radiance Gamma",
        description = "Stars Radiance Gamma",
        min = 0,
        soft_max = 3.0,
        step = 10,
        precision = 2,
        default = 0.5,
        unit = "NONE",
        subtype = "FACTOR",
        update = sun_calculation_handler
    )

    fog_toggle : BoolProperty(
        name = "Toggle Material Fog",
        description = "Apply or remove fog to all the materials",
        default = False,
        update = toggle_fog_handler
    )


def update_atmosphere_settings():
    asettings = bpy.context.scene.atmosphere_settings
    aproperties = [
        {
            "type": "string",
            "name": "preset_name",
            "attributes": {
                "update": set_current_values_as_defaults
            }
        },
        {
            "type": "string",
            "name": "preset_filename",
            "attributes": {
                "description": "Toggles Sun disk in the atmosphere",
                "default": "·_earth.py"
            }
        },
        {
            "type": "float",
            "name": "azimuth",
            "attributes": {
                "name": "Azimuth",
                "description": "Horizontal direction: at 0° the Sun is in the Y+ axis",
                "soft_min": -999,
                "soft_max": 999,
                "step": 5,
                "precision": 3,
                "default": 2.356596,
                "unit": "ROTATION",
                "update": azimuth_handler
            }
        },
        {
            "type": "float",
            "name": "elevation",
            "attributes": {
                "name": "Elevation",
                "description": "Vertical direction: at 90° the Sun is in the zenith",
                "soft_min": -999,
                "soft_max": 999,
                "step": 5,
                "precision": 3,
                "default": 3.136,
                "unit": "ROTATION",
                "update": elevation_handler
            }
        },
        {
            "type": "bool",
            "name": "sun_disk",
            "attributes": {
                "name": "Sun Disk",
                "description": "Toggles Sun disk in the atmosphere",
                "default": True,
                "update": sun_calculation_handler
            }
        },
        {
            "type": "bool",
            "name": "sun_lamp",
            "attributes": {
                "name": "Sun Lamp",
                "description": "Use Sun lamp as light source instead of Sun disk in world background",
                "default": True,
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "azimuth",
            "attributes": {
                "name": "Azimuth",
                "description": "Horizontal direction: at 0° the Sun is in the Y+ axis",
                "soft_min": -999,
                "soft_max": 999,
                "step": 5,
                "precision": 3,
                "default": asettings.azimuth,
                "unit": "ROTATION",
                "update": azimuth_handler
            }
        },
        {
            "type": "float",
            "name": "elevation",
            "attributes": {
                "name": "Elevation",
                "description": "Vertical direction: at 90° the Sun is in the zenith",
                "soft_min": -999,
                "soft_max": 999,
                "step": 5,
                "precision": 3,
                "default": asettings.elevation,
                "unit": "ROTATION",
                "update": elevation_handler
            }
        },
        {
            "type": "float",
            "name": "sun_diameter",
            "attributes": {
                "name": "Angular Diameter",
                "description": "Angular diameter of the Sun disk in degrees",
                "min": 0.001,
                "max": math.pi*0.5,
                "step": 1,
                "precision": 3,
                "default": asettings.sun_diameter,
                "unit": "ROTATION",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "floatvector",
            "name": "atmosphere_color",
            "attributes": {
                "name": "",
                "description": "Atmosphere color",
                "subtype": "COLOR_GAMMA",
                "size": 4,
                "min": 0.0,
                "max": 1.0,
                "default": asettings.atmosphere_color,
                "update": sun_calculation_handler
            }
        },
        {
            "type": "floatvector",
            "name": "atmosphere_inscattering",
            "attributes": {
                "name": "",
                "description": "Rayleigh scattering",
                "subtype": "COLOR_GAMMA",
                "size": 4,
                "min": 0.0,
                "max": 1.0,
                "default": asettings.atmosphere_inscattering,
                "update": sun_calculation_handler
            }
        },
        {
            "type": "floatvector",
            "name": "atmosphere_extinction",
            "attributes": {
                "name": "",
                "description": "Atmosphere absorption / color wavelength extinction value",
                "subtype": "COLOR_GAMMA",
                "size": 4,
                "min": 0.0,
                "max": 1.0,
                "default": asettings.atmosphere_extinction,
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "atmosphere_density",
            "attributes": {
                "name": "Density",
                "description": "Atmosphere density in kg/m3",
                "min": 0,
                "soft_max": 100,
                "step": 100,
                "precision": 2,
                "default": asettings.atmosphere_density,
                "unit": "NONE",
                "subtype": "FACTOR",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "atmosphere_height",
            "attributes": {
                "name": "Scale Height",
                "description": "Atmosphere Scale height",
                "min": 2,
                "soft_max": 4000,
                "step": 100,
                "precision": 2,
                "default": asettings.atmosphere_height,
                "unit": "LENGTH",
                "subtype": "DISTANCE",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "atmosphere_intensity",
            "attributes": {
                "name": "Intensity",
                "description": "Atmosphere Radiance Intensity in W/m2",
                "min": 0,
                "soft_max": 500,
                "step": 100,
                "precision": 2,
                "default": asettings.atmosphere_intensity,
                "unit": "NONE",
                "subtype": "FACTOR",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "night_intensity",
            "attributes": {
                "name": "Night Intensity",
                "description": "Night Sky Radiance Intensity in W/m2",
                "min": 0.000001,
                "soft_max": 0.04,
                "step": 100,
                "precision": 2,
                "default": asettings.night_intensity,
                "unit": "NONE",
                "subtype": "FACTOR",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "atmosphere_falloff",
            "attributes": {
                "name": "Falloff",
                "description": "Artistic atmosphere falloff curve",
                "min": 0,
                "max": 3.0,
                "step": 10,
                "precision": 2,
                "default": asettings.atmosphere_falloff,
                "unit": "NONE",
                "subtype": "FACTOR",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "atmosphere_mie",
            "attributes": {
                "name": "Intensity",
                "description": "Mie scattering Intensity in W/m2",
                "min": 0,
                "soft_max": 500.0,
                "step": 10,
                "precision": 2,
                "default": asettings.atmosphere_mie,
                "unit": "NONE",
                "subtype": "FACTOR",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "atmosphere_mie_dir",
            "attributes": {
                "name": "Anisotropy",
                "description": "Mie directional anisotropy",
                "min": 0,
                "max": 1.0,
                "step": 10,
                "precision": 2,
                "default": asettings.atmosphere_mie_dir,
                "unit": "NONE",
                "subtype": "FACTOR",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "atmosphere_distance",
            "attributes": {
                "name": "Distance Scalar",
                "description": "Artistic atmosphere distance scalar",
                "min": 0.0,
                "soft_max": 500,
                "step": 10,
                "precision": 2,
                "default": asettings.atmosphere_distance,
                "unit": "NONE",
                "subtype": "FACTOR",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "bool",
            "name": "ground_visible",
            "attributes": {
                "name": "Ground",
                "description": "Parametric ground visibility",
                "default": asettings.ground_visible,
                "update": sun_calculation_handler
            }
        },
        {
            "type": "floatvector",
            "name": "ground_albedo",
            "attributes": {
                "name": "",
                "description": "Ground color",
                "subtype":"COLOR_GAMMA",
                "size": 4,
                "min": 0.0,
                "max": 1.0,
                "default": asettings.ground_albedo,
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "ground_offset",
            "attributes": {
                "name": "Ground Offset",
                "description": "Parametric ground plane offset distance in meters",
                "unit": "LENGTH",
                "subtype": "DISTANCE",
                "soft_min": -200000.0,
                "soft_max": 0.0,
                "default": asettings.ground_offset,
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "horizon_offset",
            "attributes": {
                "name": "Horizon Offset",
                "description": "Slide horizon line up or down",
                "unit": "NONE",
                "subtype": "FACTOR",
                "min": -1.0,
                "max": 1.0,
                "default": asettings.horizon_offset,
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "sun_temperature",
            "attributes": {
                "name": "Temperature K",
                "description": "Sun's blackbody temperature in Kelvins",
                "min": 1000,
                "soft_max": 10000,
                "step": 100,
                "precision": 2,
                "default": asettings.sun_temperature,
                "unit": "NONE",
                "subtype": "FACTOR",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "sun_intensity",
            "attributes": {
                "name": "Intensity",
                "description": "Sun Radiance Intensity in W/m2. Influences only sun disk and ground",
                "soft_min": 100,
                "soft_max": 200000,
                "step": 100,
                "precision": 2,
                "default": asettings.sun_intensity,
                "unit": "NONE",
                "subtype": "FACTOR",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "bool",
            "name": "enable_binary_sun",
            "attributes": {
                "name": "Binary Sun",
                "description": "Use Binary Sun",
                "default": asettings.enable_binary_sun,
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "binary_distance",
            "attributes": {
                "name": "Distance",
                "description": "Distance from the Sun",
                "min": 0.0,
                "soft_max": 1,
                "step": 0.001,
                "precision": 3,
                "default": asettings.binary_distance,
                "unit": "NONE",
                "subtype": "FACTOR",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "binary_phase",
            "attributes": {
                "name": "Phase",
                "description": "Phase in context of Sun",
                "soft_min": -360,
                "soft_max": 360,
                "step": 5,
                "precision": 3,
                "default": asettings.binary_phase,
                "unit": "ROTATION",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "binary_diameter",
            "attributes": {
                "name": "Angular Diameter",
                "description": "Angular diameter of the Binary Sun disk in degrees",
                "min": 0.001,
                "max": math.pi*0.5,
                "step": 1,
                "precision": 3,
                "default": asettings.binary_diameter,
                "unit": "ROTATION",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "binary_temperature",
            "attributes": {
                "name": "Temperature K",
                "description": "Binary Sun's blackbody temperature in Kelvins",
                "min": 1000,
                "soft_max": 10000,
                "step": 100,
                "precision": 2,
                "default": asettings.binary_temperature,
                "unit": "NONE",
                "subtype": "FACTOR",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "binary_intensity",
            "attributes": {
                "name": "Intensity",
                "description": "Binary Sun Radiance Intensity in W/m2. Influences only sun disk and ground",
                "soft_min": 100,
                "soft_max": 200000,
                "step": 100,
                "precision": 2,
                "default": asettings.binary_intensity,
                "unit": "NONE",
                "subtype": "FACTOR",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "sun_radiance_gamma",
            "attributes": {
                "name": "Sun Radiance Gamma",
                "description": "Artistic Sun Radiance Gamma",
                "min": 0.01,
                "max": 3.0,
                "step": 10,
                "precision": 2,
                "default": asettings.sun_radiance_gamma,
                "unit": "NONE",
                "subtype": "FACTOR",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "enum",
            "name": "stars_type",
            "attributes": {
                "items": [('procedural', 'Procedural', 'Enable procedurally generated stars (textures loading instantly)'),
                          ('texture', 'Texture', 'Enable texture for the starmap (textures loading slowly)'),
                          ('none', 'None', 'disable stars')],
                "default": asettings.stars_type,
                "update": stars_handler
            }
        },
        {
            "type": "string",
            "name": "stars_path",
            "attributes": {
                "name": "Starmap File",
                "description": "Choose a Starmap Image File",
                "subtype": 'FILE_PATH',
                "update": stars_texture_handler,
                "default": asettings.stars_path
            }
        },
        {
            "type": "float",
            "name": "stars_intensity",
            "attributes": {
                "name": "Radiance Intensity",
                "description": "Stars Radiance Intensity",
                "min": 0,
                "soft_max": 15.0,
                "step": 10,
                "precision": 2,
                "default": asettings.stars_intensity,
                "unit": "NONE",
                "subtype": "FACTOR",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "float",
            "name": "stars_gamma",
            "attributes": {
                "name": "Radiance Gamma",
                "description": "Stars Radiance Gamma",
                "min": 0,
                "soft_max": 3.0,
                "step": 10,
                "precision": 2,
                "default": asettings.stars_gamma,
                "unit": "NONE",
                "subtype": "FACTOR",
                "update": sun_calculation_handler
            }
        },
        {
            "type": "bool",
            "name": "fog_toggle",
            "attributes": {
                "name": "Toggle Material Fog",
                "description": "Apply or remove fog to all the materials",
                "default": False,
                "update": toggle_fog_handler
            }
        }
    ]
    return aproperties


def is_iterable(n):
    """is object or array (not string)"""
    return hasattr(n, '__len__') and (not isinstance(n, str))


def align_defaults_with_preset():
    import traceback

    # TODO: figure out if there is more convenient way to duplicate current scene settings
    asettings = bpy.context.scene.atmosphere_settings
    settings_backup = {}
    for key, value in asettings.items():
        if is_iterable(value):
            settings_backup[key] = [*value]
        elif key == 'stars_type':
            settings_backup[key] = asettings.stars_type
            # print(asettings[key], value, asettings.stars_type)
            # TODO: why when iterating we get int, when accessing it directly it returns enum type string?
        else:
            settings_backup[key] = value
    path_presets = bpy.utils.user_resource('SCRIPTS', path="presets/physical-addons/psa", create=True)
    path_dest = os.path.join(path_presets, asettings.preset_filename)
    # print(path_dest)
    if os.path.exists(path_dest):
        try:
            bpy.ops.script.execute_preset(
                filepath=path_dest,
                menu_idname="RIG_MT_Presets",
            )
        except:
            traceback.print_exc()
            return False

    for attr, val in settings_backup.items():
        setattr(asettings, attr, val)
