import bpy
import os
from mathutils import Euler
from . sunlight import *
from . fog import *
from . presets import DefaultPresets


def enable_atmosphere(self, context):
    gsettings = bpy.context.scene.general_settings
    asettings = bpy.context.scene.atmosphere_settings
    depsgraph = bpy.context.evaluated_depsgraph_get()
    if gsettings.enabled:
        create_sun()
        create_atmosphere()
        # toggle_physical_values(settings, bpy.context)  # if physical values enabled in addon preferences set right
        # intensity multiplier TODO: replace function if/else statement with call to a function
        addon_prefs = context.preferences.addons['physical-starlight-atmosphere'].preferences
        if addon_prefs.use_physical_values:
            gsettings.intensity_multiplier = 100
        else:
            gsettings.intensity_multiplier = 1
        sun_calculation(context, depsgraph, 'realtime')
        stars_handler(asettings, context)  # See which option is selected in settings and enable it (link it)
        gsettings.initialized = True  # In order not to run sun calculation before create atmosphere
        gsettings.material_count = len(bpy.data.materials)  # Needed for fog to compare with previous material count
        gsettings.sun_pos_checksum = asettings.azimuth + asettings.elevation  # Has sun moved using obj or az/el
        if len(asettings.stars_path) > 0:  # In some systems stars_path is not set by default (folder config issue?)
            stars_texture_handler(asettings, bpy.context)  # If texture exists - apply it
        DefaultPresets()  # copy presets from addon to user folder if missing
    else:
        if gsettings.fog_enabled:
            asettings.fog_toggle = False
        gsettings.initialized = False
        current_world = bpy.context.scene.world
        if current_world is not None and current_world.name.startswith("Atmosphere"):
            remove_atmosphere(current_world)
        remove_sun()


def sun_calculation_handler(self, context):
    depsgraph = bpy.context.evaluated_depsgraph_get()
    sun_calculation(context, depsgraph, 'realtime')


def azimuth_handler(self, context):
    gsettings = bpy.context.scene.general_settings
    asettings = bpy.context.scene.atmosphere_settings
    if gsettings.silent_update:
        return
    sun = get_object("Starlight Sun")
    if sun is not None:
        azimuth = asettings.azimuth
        if round(sun.rotation_euler[2], 5) != round(math.pi-azimuth, 5):
            sun.rotation_euler[2] = math.pi-azimuth
        if sun.rotation_euler[1] != 0:  # lock sun rotation to simulate global rotate
            sun.rotation_euler[1] = 0


def elevation_handler(self, context):
    gsettings = bpy.context.scene.general_settings
    asettings = bpy.context.scene.atmosphere_settings
    if gsettings.silent_update:
        return
    sun = get_object("Starlight Sun")
    if sun is not None:
        elevation = asettings.elevation
        if round(sun.rotation_euler[0], 5) != round(math.pi/2-elevation, 5):
            sun.rotation_euler[0] = math.pi/2-elevation
        if sun.rotation_euler[1] != 0:  # lock sun rotation to simulate global rotate
            sun.rotation_euler[1] = 0


def create_sun():
    light_data = bpy.data.lights.new(name="Starlight Sun", type='SUN')
    light_object = bpy.data.objects.new(name="Starlight Sun", object_data=light_data)
    light_object.location = (0, 0, 10)
    light_object.rotation_euler = Euler((-1.565, 0.3, 0.785), 'XYZ')
    light_data.shadow_cascade_max_distance = 2000
    bpy.context.collection.objects.link(light_object)  # link light object
    bpy.context.view_layer.objects.active = light_object  # make it active


def remove_sun():
    sun = get_object("Starlight Sun")
    if sun:
        light = sun.data
        bpy.data.lights.remove(light)


def create_atmosphere():
    current_world = bpy.context.scene.world
    if current_world is not None and current_world.name.startswith("Atmosphere"):
        remove_atmosphere(current_world)

    if not has_world("Atmosphere"):  # Creates Node Groups
        path = os.path.join(os.path.dirname(__file__), "blends/atmosphere.blend/World/")
        bpy.ops.wm.append(directory=path, filepath="Atmosphere"+".blend", filename="Atmosphere")
        bpy.context.scene.world = bpy.data.worlds["Atmosphere"]  # assigns the new world
    else:
        atmosphere = get_world("Atmosphere")
        bpy.context.scene.world = atmosphere.copy()


def remove_atmosphere(atmosphere):
    #  remove the wold data
    # print('removing atmosphere', atmosphere)
    bpy.data.worlds.remove(atmosphere)

    # if this was the last Atmosphere, then cleanup the blenderfile
    if not has_world('Atmosphere'):
        purge_node_groups()

    #  restoring the default World node
    if "World" in bpy.data.worlds:
        bpy.context.scene.world = bpy.data.worlds["World"]
    else:
        bpy.context.scene.world = bpy.data.worlds.new("World")


def purge_node_groups():
    """ Delete all Node Groups from the blenderfile """
    #  list of shader node groups in addon
    nodeTreeGroupArray = [
        "StarlightAtmosphere",
        ". calculate_fog_object",
        ". calculate_fog_world",
        ". calculate_scattering",
        ". calculcate_scattering_object",
        ". smoothstep()",
        ". camera_position",
        ". camera_position_world",
        ". clamp()",
        ". earth_shadow_hack",
        ". exp()",
        ". flat_world",
        ". intersect_plane",
        ". length()",
        ". mie_scattering",
        ". ray_plane_intersection",
        ". sun_ground_radiance",
        ". sun_limb_darkening_radiance",
        ". binary_star_position",
    ]
    for x in nodeTreeGroupArray:
        for g in bpy.data.node_groups:
            if x in g.name:
                bpy.data.node_groups.remove(g)


def toggle_fog_handler(self, context):
    gsettings = bpy.context.scene.general_settings
    if gsettings.fog_enabled:
        gsettings.fog_enabled = False
        toggle_fog(0)
    else:
        gsettings.fog_enabled = True
        toggle_fog(1)


def remove_link(from_node, to_node):
    node_tree = bpy.context.scene.world.node_tree.nodes["StarlightAtmosphere"].node_tree
    output = from_node.outputs[0]
    input = to_node.inputs[0]
    for l in output.links :
        if l.to_socket == input :
            node_tree.links.remove(l)


def stars_handler(self, context):
    asettings = context.scene.atmosphere_settings
    stars_type = asettings.stars_type

    world = bpy.context.scene.world
    if world is None:
        return
    atmosphere = world.node_tree.nodes["StarlightAtmosphere"].node_tree
    procedural_node = atmosphere.nodes['procedural_starmap']
    texture_node = atmosphere.nodes['starmap']
    output_node = atmosphere.nodes['stars_output']

    # remove any existing link
    remove_link(procedural_node, output_node)
    remove_link(texture_node, output_node)

    if stars_type == 'texture':
        atmosphere.links.new(texture_node.outputs[0], output_node.inputs[0])
    elif stars_type == 'procedural':
        atmosphere.links.new(procedural_node.outputs[0], output_node.inputs[0])
    output_node.outputs[0].default_value = (0, 0, 0, 1)  # node_tree.reload() alternative to refresh node tree


def stars_texture_handler(self, context):
    world = bpy.context.scene.world
    if world is None:
        return
    atmosphere = world.node_tree.nodes["StarlightAtmosphere"].node_tree
    asettings = bpy.context.scene.atmosphere_settings
    try:
        atmosphere.nodes['starmap'].image = bpy.data.images.load(asettings.stars_path, check_existing=True)
    except:
        pass