import bpy
import os

def get_previous_node(node):
    for in_socket in node.inputs:
        if in_socket.is_linked:
            for link in in_socket.links:
                if link.is_valid:
                    return link.from_node


def create_atmosphere_node(mat_nodes):
    if "StarlightAtmosphere" in bpy.data.node_groups:
        group = bpy.data.node_groups["StarlightAtmosphere"]  # fetch already existing group
        # create and add the new node to the tree
        atmosphere_node = mat_nodes.new(type='ShaderNodeGroup')
        atmosphere_node.name = "StarlightAtmosphere"
        atmosphere_node.node_tree = group  # assign the existing group
        return atmosphere_node


# pass 1 to enable for and 0 to remove it
def toggle_fog(add):
    # get all materials
    for mat in bpy.data.materials:
        mat.use_nodes = True  # enable 'Use nodes' if not enabled already
        node_tree = mat.node_tree
        nodes = node_tree.nodes

        material_output = mat.node_tree.get_output_node('ALL')  # get the output node
        if material_output == None:
            # print('Case 1: No output - in any case do nothing')
            continue  # jump to next material

        previous_node = get_previous_node(material_output)  # last node to connect to output node
        if "StarlightAtmosphere" in nodes and previous_node != nodes.get("StarlightAtmosphere"):
            # print('Case 2: Invalid Atmosphere node (not connected to output) - delete it')
            nodes.remove(nodes.get("StarlightAtmosphere"))  # cleanup node editor

        if add == 1:  # ADD FOG
            if "StarlightAtmosphere" in nodes: #  and is connected to output
                continue  # everything is awesome - jump to next material

            starlight_node = create_atmosphere_node(nodes)

            if previous_node == None:
                # print('Case 3: [+] Only output - add and link Atmosphere')
                node_tree.links.new(starlight_node.outputs[0], material_output.inputs[0])
                move_node_in_between(None, starlight_node, material_output)
            else:
                # print('Case 4: [+] Has output & node before - link Atmosphere in between')
                node_tree.links.new(previous_node.outputs[0], starlight_node.inputs[1])
                node_tree.links.new(starlight_node.outputs[0], material_output.inputs[0])
                move_node_in_between(previous_node, starlight_node, material_output)


        else:  # REMOVE FOG
            if not nodes.get("StarlightAtmosphere"):  # only in case material contains this node
                continue  # if there is no Atmosphere node - jump to next material

            previous_previous_node = get_previous_node(previous_node)

            if previous_previous_node == None:
                # print('Case 5: [-] Atmosphere exists & nothing before - remove Atmosphere')
                nodes.remove(nodes.get("StarlightAtmosphere"))
            else:
                # print('Case 6: [-] Atmosphere exists & something before - Link nodes and remove Atmosphere')
                node_tree.links.new(previous_previous_node.outputs[0], material_output.inputs[0])
                nodes.remove(nodes.get("StarlightAtmosphere"))


def move_node_in_between(node_before, the_node, node_after):
    node_padding = 40
    if node_before is None:
        the_node.location.xy = (node_after.location.x - node_after.width - node_padding, node_after.location.y)
    else:
        the_node_xpos = node_before.location.x + node_padding + node_before.width
        node_after_xpos = the_node_xpos + node_padding + node_after.width
        the_node.location.xy = (the_node_xpos, node_before.location.y)
        node_after.location.xy = (node_after_xpos, node_before.location.y)