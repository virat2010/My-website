import bpy
from bpy.types import Panel, Operator, AddonPreferences, Menu
from . handlers import *
from . presets import RIG_MT_Presets, RIG_OT_AddPreset

############################################################################
# BASE CLASES
############################################################################
# Base for World tab and not sure how to call it.
class RIG_WT:
    bl_parent_id = "RIG_PT_StarlightAtmosphereWT"
    bl_region_type = "WINDOW"
    bl_space_type = "PROPERTIES"
    bl_context = "world"
class RIG_TB:
    bl_parent_id = "RIG_PT_StarlightAtmosphereTB"
    bl_region_type = "UI"
    bl_space_type = "VIEW_3D"
    bl_context = "objectmode"

# Base class
class DrawablePanel:
    @classmethod
    def poll(self, context):
        settings_available = context.scene and hasattr(context.scene, 'atmosphere_settings')
        if not settings_available:
            return False
        # toolbar preferences are stored under preferences Class.
        addon_prefs = context.preferences.addons['physical-starlight-atmosphere'].preferences
        if self.bl_context == "objectmode" and not addon_prefs.toolbar_enabled:  # if drawing toolbar but it's not enabled
            return False
        return True

    def draw_header(self, context):
        self.layout.label(text='', icon=self.icon_name)

    # indented column with a padding from left
    def indentedColumn(self, squished=True):
        row = self.layout.row()
        row.separator()
        return row.column(align=squished)

    # simplify ui creation
    def add_reset_button(self):
        row = self.layout.row()
        row.alignment = "RIGHT"
        reset = row.operator(RIG_OT_ResetDefault.bl_idname, icon='FILE_REFRESH')
        reset.properties_type = self.properties_type


############################################################################
# StarlightAtmosphere
############################################################################

class StarlightAtmosphere(DrawablePanel):
    bl_label = "Physical Atmosphere"

    def draw_header(self, context):
        if context.scene and hasattr(context.scene, 'general_settings'):
            settings = context.scene.general_settings
            layout = self.layout
            layout.prop(settings, 'enabled', text='')

    def draw(self, context):
        gsettings = context.scene.general_settings
        layout = self.layout
        layout.enabled = gsettings.enabled
        col = layout.column(align=True)
        col.label(text='Presets:')
        row = col.row(align=True)
        row.menu(RIG_MT_Presets.__name__, text=RIG_MT_Presets.bl_label)
        row.operator(RIG_OT_AddPreset.bl_idname, text="", icon='ADD')
        row.operator(RIG_OT_AddPreset.bl_idname, text="", icon='REMOVE').remove_active = True


class RIG_PT_StarlightAtmosphereWT(Panel, StarlightAtmosphere):
    bl_idname = "RIG_PT_StarlightAtmosphereWT"
    bl_region_type = "WINDOW"            # location of the panel
    bl_space_type = "PROPERTIES"
    bl_context = "world"


class RIG_PT_StarlightAtmosphereTB(Panel, StarlightAtmosphere):
    bl_idname = "RIG_PT_StarlightAtmosphereTB"
    bl_region_type = "UI"          # location of the panel
    bl_space_type = "VIEW_3D"      # Region not found in space type if PROPERTIES used
    bl_context = "objectmode"      # without objectmode it is not appearing as a tab
    bl_category = "Atmosphere"      # Tab label

############################################################################
# Sun
############################################################################
class Sun(DrawablePanel):
    bl_label = "Sun"
    icon_name = "LIGHT_SUN"
    properties_type = "sun"

    def draw(self, context):
        if context.scene and hasattr(context.scene, 'general_settings'):
            prefs = bpy.context.preferences.addons['physical-starlight-atmosphere'].preferences
            gsettings = context.scene.general_settings
            asettings = context.scene.atmosphere_settings
            layout = self.layout
            layout.enabled = gsettings.enabled
            col = self.indentedColumn()
            col.prop(asettings, 'azimuth')
            col.prop(asettings, 'elevation')
            col.prop(asettings, 'sun_disk')
            col.prop(asettings, 'sun_lamp')
            col.prop(asettings, 'sun_diameter')
            col.prop(asettings, 'sun_temperature')
            col.prop(asettings, 'sun_intensity')
            if prefs.use_experimental_features:
                col.prop(asettings, 'enable_binary_sun')
            self.add_reset_button()


class RIG_PT_SunWT(RIG_WT, Panel, Sun):
    pass

class RIG_PT_SunTB(RIG_TB, Panel, Sun):
    pass


############################################################################
# Binary Sun
############################################################################
class BinarySun(DrawablePanel):
    bl_label = "Binary Sun"
    icon_name = "LIGHT_SUN"
    properties_type = "binary_sun"

    @classmethod
    def poll(self, context):
        prefs = context.preferences.addons['physical-starlight-atmosphere'].preferences
        asettings = context.scene.atmosphere_settings
        if prefs.use_experimental_features and asettings.enable_binary_sun:
            settings_available = context.scene and hasattr(context.scene, 'atmosphere_settings')
            if not settings_available:
                return False
            if self.bl_context == "objectmode" and not prefs.toolbar_enabled:
                return False
            return True
        else:
            return False


    def draw(self, context):
        if context.scene and hasattr(context.scene, 'general_settings'):
            gsettings = context.scene.general_settings
            asettings = context.scene.atmosphere_settings
            layout = self.layout
            layout.enabled = gsettings.enabled
            col = self.indentedColumn()
            col.prop(asettings, 'binary_distance')
            col.prop(asettings, 'binary_phase')
            col.prop(asettings, 'binary_diameter')
            col.prop(asettings, 'binary_temperature')
            col.prop(asettings, 'binary_intensity')
            self.add_reset_button()


class RIG_PT_BinarySunWT(RIG_WT, Panel, BinarySun):
    pass

class RIG_PT_BinarySunTB(RIG_TB, Panel, BinarySun):
    pass


############################################################################
# Atmosphere
############################################################################
class Atmosphere(DrawablePanel):
    bl_label = "Atmosphere"
    icon_name= "WORLD_DATA"
    properties_type = "atmosphere"

    def draw(self, context):
        gsettings = context.scene.general_settings
        asettings = context.scene.atmosphere_settings
        layout = self.layout
        layout.enabled = gsettings.enabled

        col = self.indentedColumn()
        col.prop(asettings, 'atmosphere_density')
        col.prop(asettings, 'atmosphere_height')
        col.prop(asettings, 'atmosphere_intensity')
        col = self.indentedColumn()
        col.prop(asettings, 'night_intensity')

        # inline color fields
        col = self.indentedColumn()
        row = col.row(align=True)
        row.label(text='Color:')
        row.prop(asettings, 'atmosphere_color')
        row = col.row(align=True)
        row.label(text='Inscattering:')
        row.prop(asettings, 'atmosphere_inscattering')
        row = col.row(align=True)
        row.label(text='Absorption:')
        row.prop(asettings, 'atmosphere_extinction')

        col.label(text='Mie Scattering:')
        col.prop(asettings, 'atmosphere_mie')
        col.prop(asettings, 'atmosphere_mie_dir')
        self.add_reset_button()

class RIG_PT_AtmosphereWT(RIG_WT, Panel, Atmosphere):
    pass

class RIG_PT_AtmosphereTB(RIG_TB, Panel, Atmosphere):
    pass


############################################################################
# Stars
############################################################################
class Stars(DrawablePanel):
    bl_label = "Stars"
    icon_name = 'STICKY_UVS_DISABLE'
    properties_type = "stars"

    def draw(self, context):
        if context.scene and hasattr(context.scene, 'general_settings'):
            gsettings = context.scene.general_settings
            asettings = context.scene.atmosphere_settings
            stars_type = asettings.stars_type
            layout = self.layout
            layout.enabled = gsettings.enabled

            row = layout.row(align=True)
            row.prop(asettings, 'stars_type', expand=True)

            if stars_type in {'procedural', 'texture'}:
                col = self.indentedColumn()
            if stars_type == 'texture':

                col.prop(asettings, 'stars_path', text="")
            if stars_type in {'procedural', 'texture'}:
                col.prop(asettings, 'stars_intensity')
                col.prop(asettings, 'stars_gamma')
                self.add_reset_button()


class RIG_PT_StarsWT(RIG_WT, Panel, Stars):
    pass


class RIG_PT_StarsTB(RIG_TB, Panel, Stars):
    pass


############################################################################
# Ground
############################################################################
class Ground(DrawablePanel):
    bl_label = "Ground"
    icon_name = "VIEW_PERSPECTIVE"
    properties_type = "ground"

    def draw(self, context):
        if context.scene and hasattr(context.scene, 'general_settings'):
            gsettings = context.scene.general_settings
            asettings = context.scene.atmosphere_settings
            layout = self.layout
            layout.enabled = gsettings.enabled

            col = self.indentedColumn(False)
            row = col.row(align=True)
            col.prop(asettings, 'ground_visible')
            row.label(text='Color:')
            row.prop(asettings, 'ground_albedo')
            col.prop(asettings, 'ground_offset')
            col.prop(asettings, 'horizon_offset')
            if bpy.app.version > (2, 83, 0):  # quick icon fix for version lower than 2.82
                col.prop(asettings, 'fog_toggle', icon='MOD_FLUID')
            else:
                col.prop(asettings, 'fog_toggle')
            self.add_reset_button()


class RIG_PT_GroundWT(RIG_WT, Panel, Ground):
    pass


class RIG_PT_GroundTB(RIG_TB, Panel, Ground):
    pass


############################################################################
# ArtisticControls
############################################################################
class ArtisticControls(DrawablePanel):
    bl_label = "Artistic Controls"
    icon_name = "SHADERFX"
    properties_type = "artisticcontrols"

    def draw(self, context):
        gsettings = context.scene.general_settings
        asettings = context.scene.atmosphere_settings
        layout = self.layout
        layout.enabled = gsettings.enabled

        col = self.indentedColumn()
        col.prop(asettings, 'atmosphere_distance')
        col.prop(asettings, 'atmosphere_falloff')
        col.prop(asettings, 'sun_radiance_gamma')
        self.add_reset_button()


class RIG_PT_ArtisticControlsWT(RIG_WT, Panel, ArtisticControls):
    pass


class RIG_PT_ArtisticControlsTB(RIG_TB, Panel, ArtisticControls):
    pass


############################################################################
# Reset Button
############################################################################
class RIG_OT_ResetDefault(Operator):
    bl_idname = "rig.reset_btn"
    bl_label = "reset"
    bl_description = "Reset values to default"
    properties_type: bpy.props.StringProperty()

    def execute(self, context):
        gsettings = context.scene.general_settings
        asettings = context.scene.atmosphere_settings
        if self.properties_type == 'sun':
            asettings.property_unset('sun_disk')
            asettings.property_unset('sun_lamp')
            asettings.property_unset('sun_diameter')
            asettings.property_unset('sun_temperature')
            asettings.property_unset('sun_intensity')
        if self.properties_type == 'binary_sun':
            asettings.property_unset('binary_distance')
            asettings.property_unset('binary_phase')
            asettings.property_unset('binary_diameter')
            asettings.property_unset('binary_temperature')
            asettings.property_unset('binary_intensity')
        elif self.properties_type == 'atmosphere':
            asettings.property_unset('atmosphere_density')
            asettings.property_unset('atmosphere_height')
            asettings.property_unset('atmosphere_intensity')
            asettings.property_unset('night_intensity')
            asettings.property_unset('atmosphere_color')
            asettings.property_unset('atmosphere_inscattering')
            asettings.property_unset('atmosphere_extinction')
            asettings.property_unset('atmosphere_mie')
            asettings.property_unset('atmosphere_mie_dir')
        elif self.properties_type == 'stars':
            asettings.property_unset('stars_path')
            asettings.property_unset('stars_intensity')
            asettings.property_unset('stars_gamma')
            asettings.property_unset('atmosphere_intensity')
        elif self.properties_type == 'ground':
            asettings.property_unset('ground_albedo')
            asettings.property_unset('ground_offset')
            asettings.property_unset('horizon_offset')
            asettings.property_unset('fog_toggle')
            if gsettings.fog_enabled:
                toggle_fog(0)
                gsettings.fog_enabled = False
        elif self.properties_type == 'artisticcontrols':
            asettings.property_unset('atmosphere_distance')
            asettings.property_unset('atmosphere_falloff')
            asettings.property_unset('sun_radiance_gamma')

        sun_calculation_handler(self, bpy.context)  # recalculate atmosphere based on reset values
        return {'FINISHED'}
