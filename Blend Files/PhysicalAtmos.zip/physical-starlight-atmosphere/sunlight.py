import bpy
import mathutils
from . helpers import *


def get_object(name):
    """ Get object from scene context (even if prefixed with e.g. 002) """
    for obj in bpy.context.scene.objects:
        if obj.name.startswith(name):
            return obj
    return None


def has_world(name):
    """ Return True if bpy.data.worlds contain this world (even if prefixed with e.g. 002) """
    for world in bpy.data.worlds:
        if world.name.startswith(name):
            return True
    return False


def get_world(name):  # get_first_world_that_starts_with
    """ Return world if bpy.data.worlds contain this world (even if prefixed with e.g. 002) """
    for world in bpy.data.worlds:
        if world.name.startswith(name):
            return world
    return False




def sun_calculation(context, depsgraph, mode):
    gsettings = context.scene.general_settings
    asettings = context.scene.atmosphere_settings

    atmosphere_height = asettings.atmosphere_height
    atmosphere_density = asettings.atmosphere_density

    infinity = 1000000  # not an infinity at all, but a value that makes look "flat" earth to be round

    intensity = asettings.sun_intensity * gsettings.intensity_multiplier

    # Sun
    sun = get_object("Starlight Sun")
    if sun is None:
        return

    if mode == 'rendering':  # Update sun position in scene

        if sun_moved_using_azimuth_elevation():
            # print('using: azimuth + elevation')
            sun.rotation_euler[2] = math.pi - asettings.azimuth
            sun.rotation_euler[0] = math.pi/2 - asettings.elevation
        else:
            # print('using: sun object rotation by handle')
            sun = sun.evaluated_get(depsgraph)  # whenever sun is modified using object handle


    atmosphere = bpy.context.scene.world.node_tree.nodes["StarlightAtmosphere"].node_tree

    # Calculating the sun intensity and color
    ray = mathutils.Vector((0, 0, -1))
    ray.rotate(sun.rotation_euler)
    ray.normalized()
    p = ray*infinity

    eye = mathutils.Vector((0, 0, 0.5))  # ground level. to do -> make viewer level
    eye2 = mathutils.Vector((0, 0, atmosphere_height))  # ground level. to do -> make viewer level

    a = 1.0-math.exp(p[2]/atmosphere_height)
    b = math.exp((eye[2]-asettings.ground_offset)*-1.0/atmosphere_height) * (atmosphere_density)
    b2 = math.exp((eye2[2]-asettings.ground_offset)*-1.0/atmosphere_height) * (atmosphere_density)
    fog = ((a*b)/ray[2])
    fog = fog*-1  # fog here is negative, we need to pow() it so we make it positive
    fog = min(fog, 1e+22)  # shader has it to fix something, forgot what.
    fog = math.pow(fog, asettings.atmosphere_falloff)
    fog = fog*asettings.atmosphere_distance*-1  # make it negative again

    fog2 = ((a*b2)/ray[2])
    fog2 = fog2*-1  # fog here is negative, we need to pow() it so we make it positive
    fog2 = min(fog2, 1e+22)  # shader has it to fix something, forgot what.
    fog2 = math.pow(fog2, asettings.atmosphere_falloff)
    fog2 = fog2*asettings.atmosphere_distance*-1  # make it negative again

    steridianLamp = 2*math.pi*(1.0-math.cos(0.00918/2))#0.00918 = sun diameter default
    steridianDisk = 1.0/(2*math.pi*(1.0-math.cos(asettings.sun_diameter/2)))
    binary_steridianDisk = 1.0/(2*math.pi*(1.0-math.cos(asettings.binary_diameter/2)))

    scatter = asettings.atmosphere_inscattering
    absorption = asettings.atmosphere_extinction

    sun_color = Helpers.convert_K_to_RGB(asettings.sun_temperature)
    atmosphere.nodes['sun_color'].outputs[0].default_value = (sun_color[0], sun_color[1], sun_color[2], 1)

    binary_sun_color = Helpers.convert_K_to_RGB(asettings.binary_temperature)
    atmosphere.nodes['binary_sun_color'].outputs[0].default_value = (binary_sun_color[0], binary_sun_color[1], binary_sun_color[2], 1)

    scatR = (1.0 - math.exp(scatter[0]*fog)) * asettings.atmosphere_color[0]
    scatG = (1.0 - math.exp(scatter[1]*fog)) * asettings.atmosphere_color[1]
    scatB = (1.0 - math.exp(scatter[2]*fog)) * asettings.atmosphere_color[2]

    absorptR = math.exp((1.0-absorption[0])*fog) * sun_color[0] * intensity
    absorptG = math.exp((1.0-absorption[1])*fog) * sun_color[1] * intensity
    absorptB = math.exp((1.0-absorption[2])*fog) * sun_color[2] * intensity

    scatR2 = (1.0 - math.exp(scatter[0]*fog2)) * asettings.atmosphere_color[0]
    scatG2 = (1.0 - math.exp(scatter[1]*fog2)) * asettings.atmosphere_color[1]
    scatB2 = (1.0 - math.exp(scatter[2]*fog2)) * asettings.atmosphere_color[2]

    absorptR2 = math.exp((1.0-absorption[0])*fog2) * sun_color[0] * intensity
    absorptG2 = math.exp((1.0-absorption[1])*fog2) * sun_color[1] * intensity
    absorptB2 = math.exp((1.0-absorption[2])*fog2) * sun_color[2] * intensity

    # Sun Ground Radiance
    #vert = ray.dot(mathutils.Vector((0, 0, -1)))
    #sun_ground_radiance = Helpers.smoothstep(vert, -asettings.sun_diameter*0.5, asettings.sun_diameter*0.5)

    # Sun Strength
    if asettings.sun_lamp:
        sun.data.energy = 1.0
    else:
        sun.data.energy = 0.0

    # Calculate basic attenuation based on sun diameter
    #denom = 2.0/settings.sun_diameter + 1.0
    #lamp_intensity = (1.0 / (denom*denom))

    #Sun Color
    sunColor = [
        Helpers.gamma_correction((scatR+absorptR)*steridianLamp, asettings.sun_radiance_gamma),
        Helpers.gamma_correction((scatG+absorptG)*steridianLamp, asettings.sun_radiance_gamma),
        Helpers.gamma_correction((scatB+absorptB)*steridianLamp, asettings.sun_radiance_gamma)
    ]

    sunColorUpper = [
        Helpers.gamma_correction((scatR2+absorptR2)*steridianLamp, asettings.sun_radiance_gamma),
        Helpers.gamma_correction((scatG2+absorptG2)*steridianLamp, asettings.sun_radiance_gamma),
        Helpers.gamma_correction((scatB2+absorptB2)*steridianLamp, asettings.sun_radiance_gamma)
    ]

    # Apply color an angle to lamp and sky
    sun.data.color = [sunColor[0], sunColor[1], sunColor[2]]
    atmosphere.nodes['sun_light'].outputs[0].default_value = (sunColor[0], sunColor[1], sunColor[2], 1)
    atmosphere.nodes['sun_light_upper'].outputs[0].default_value = (sunColorUpper[0], sunColorUpper[1], sunColorUpper[2], 1)
    atmosphere.nodes['steridian'].outputs[0].default_value = steridianLamp*steridianDisk
    atmosphere.nodes['binary_steridian'].outputs[0].default_value = steridianLamp*binary_steridianDisk
    sun.data.angle = asettings.sun_diameter

    # Atmosphere
    atmosphere_calculation(asettings, gsettings,  sun)


# Atmosphere
def atmosphere_calculation(asettings, gsettings, sun):


    atmosphere_height = asettings.atmosphere_height
    atmosphere_density = asettings.atmosphere_density

    atmosphere_color = asettings.atmosphere_color
    atmosphere_inscattering = asettings.atmosphere_inscattering
    atmosphere_extinction = asettings.atmosphere_extinction

    atmosphere_mie = asettings.atmosphere_mie * gsettings.intensity_multiplier
    atmosphere_mie_dir = asettings.atmosphere_mie_dir

    atmosphere_distance = asettings.atmosphere_distance
    atmosphere_falloff = asettings.atmosphere_falloff

    ground_visible = asettings.ground_visible
    ground_albedo = asettings.ground_albedo
    ground_offset = asettings.ground_offset
    horizon_offset = asettings.horizon_offset

    atmosphere = bpy.context.scene.world.node_tree.nodes["StarlightAtmosphere"].node_tree

    # Atmosphere rotation
    vec = mathutils.Vector((0, 0, 1))
    vec.rotate(sun.rotation_euler)
    # Planet's shadow hack thing
    vec1 = mathutils.Vector((0, 1, 0))
    vec1.rotate(sun.rotation_euler)

    vec2 = mathutils.Vector((1, 0, 0))
    vec2.rotate(sun.rotation_euler)

    atmosphere.nodes['sun_rot'].outputs[0].default_value = mathutils.Vector((
        math.degrees(sun.rotation_euler[0]),
        math.degrees(sun.rotation_euler[1]),
        math.degrees(sun.rotation_euler[2])
    ))

    atmosphere.nodes['sun_dir'].outputs[0].default_value = vec
    atmosphere.nodes['sun_up'].outputs[0].default_value = vec1
    atmosphere.nodes['sun_right'].outputs[0].default_value = vec2

    atmosphere.nodes['sun_diameter'].outputs[0].default_value = asettings.sun_diameter
    atmosphere.nodes['binary_sun_diameter'].outputs[0].default_value = asettings.binary_diameter

    atmosphere.nodes['binary_phase'].outputs[0].default_value = asettings.binary_phase
    atmosphere.nodes['binary_distance'].outputs[0].default_value = asettings.binary_distance


    if asettings.sun_disk == False:
        atmosphere.nodes['sun_intensity'].outputs[0].default_value = 0.0
        atmosphere.nodes['binary_sun_intensity'].outputs[0].default_value = 0.0
    else:
        atmosphere.nodes['sun_intensity'].outputs[0].default_value = asettings.sun_intensity * gsettings.intensity_multiplier
        atmosphere.nodes['binary_sun_intensity'].outputs[0].default_value = asettings.binary_intensity * gsettings.intensity_multiplier

    if asettings.sun_disk and asettings.sun_lamp:
    	atmosphere.nodes['sun_intensity'].outputs[0].default_value = asettings.sun_intensity * gsettings.intensity_multiplier * 0.05
    	atmosphere.nodes['binary_sun_intensity'].outputs[0].default_value = asettings.binary_intensity * gsettings.intensity_multiplier * 0.05

    if asettings.enable_binary_sun == False:
        atmosphere.nodes['binary_sun_intensity'].outputs[0].default_value = 0.0

    atmosphere.nodes['night_radiance'].outputs[0].default_value = asettings.night_intensity

    atmosphere.nodes['atmosphere_height'].outputs[0].default_value = atmosphere_height
    atmosphere.nodes['atmosphere_density'].outputs[0].default_value = atmosphere_density

    atmosphere.nodes['atmosphere_intensity'].outputs[0].default_value = asettings.atmosphere_intensity * gsettings.intensity_multiplier

    atmosphere.nodes['atmosphere_color'].outputs[0].default_value = atmosphere_color
    atmosphere.nodes['atmosphere_inscattering'].outputs[0].default_value = atmosphere_inscattering
    atmosphere.nodes['atmosphere_extinction'].outputs[0].default_value = atmosphere_extinction

    atmosphere.nodes['atmosphere_mie'].outputs[0].default_value = atmosphere_mie
    atmosphere.nodes['atmosphere_mie_dir'].outputs[0].default_value = atmosphere_mie_dir

    atmosphere.nodes['atmosphere_distance'].outputs[0].default_value = atmosphere_distance
    atmosphere.nodes['atmosphere_falloff'].outputs[0].default_value = atmosphere_falloff
    # ground
    atmosphere.nodes['ground_visible'].outputs[0].default_value = ground_visible
    atmosphere.nodes['ground_albedo'].outputs[0].default_value = ground_albedo
    atmosphere.nodes['ground_offset'].outputs[0].default_value = ground_offset
    atmosphere.nodes['horizon_offset'].outputs[0].default_value = horizon_offset
    # stars
    atmosphere.nodes['stars_radiance_intensity'].outputs[0].default_value = asettings.stars_intensity * gsettings.intensity_multiplier
    atmosphere.nodes['stars_radiance_gamma'].outputs[0].default_value = asettings.stars_gamma


def sun_moved_using_azimuth_elevation():
    # check if azimuth or elevation values in previous scene were different
    gsettings = bpy.context.scene.general_settings
    asettings = bpy.context.scene.atmosphere_settings
    # rounding fixes comparing bug
    if round(gsettings.sun_pos_checksum, 5) != round(asettings.azimuth + asettings.elevation, 5):
        gsettings.sun_pos_checksum = asettings.azimuth + asettings.elevation
        return True
    return False
