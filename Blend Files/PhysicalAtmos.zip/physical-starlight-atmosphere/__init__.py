# Addon Info
bl_info = {
	"name": "Physical Starlight and Atmosphere",
	"author": "Martins Upitis, Karlis Upitis",
	"version": (1, 4, 1),
	"blender": (2, 90, 0),
	"description": "Physical Starlight and Atmosphere",
	"location": "World > Atmosphere",
	"warning": "beta version (not production ready)",
	"wiki_url": "https://www.physicaladdons.com/psa/",
	"support": "COMMUNITY",
	"category": "Lighting",
	"tracker_url": "https://github.com/PhysicalAddons/physical-starlight-and-atmosphere/issues"
	}

import bpy
from bpy.props import *
from bpy.app.handlers import persistent
from threading import Timer

from . properties import *
from . preferences import *
from . sunlight import *
from . ui import *
from . presets import RIG_MT_Presets, RIG_OT_AddPreset
from . clouds import RIG_PT_PhysicalCloudsTB, RIG_PT_PhysicalCloudsWT


if locals().get('loaded'):
	loaded = False
	from importlib import reload
	from sys import modules

	modules[__name__] = reload(modules[__name__])
	for name, module in modules.items():
		if name.startswith(f"{__package__}."):
			globals()[name] = reload(module)
	del reload, modules


def update_azimuth_elevation(asettings):
	gsettings = bpy.context.scene.general_settings
	sun = get_object("Starlight Sun")
	if sun is None:
		return False
	gsettings.silent_update = True
	azimuth_changed = round(math.pi - sun.rotation_euler[2], 5) != round(asettings.azimuth, 5)
	elevation_changed = round(math.pi/2 - sun.rotation_euler[0], 5) != round(asettings.elevation, 5)
	if azimuth_changed:
		asettings.azimuth = math.pi - sun.rotation_euler[2]
	if elevation_changed:
		asettings.elevation = math.pi/2 - sun.rotation_euler[0]
	gsettings.silent_update = False


sun_rotation_timer = Timer(0.3, update_azimuth_elevation)
def throttle_azimuth_elevation_update(asettings):
	global sun_rotation_timer
	sun_rotation_timer.cancel()
	sun_rotation_timer = Timer(0.3, update_azimuth_elevation, [asettings])
	sun_rotation_timer.start()


def tuple_to_str(n):
	""" Concat tuple and nested tuple in string """
	if type(n).__name__ == 'bpy_prop_array':
		return "".join(map(str, n))
	else:
		return str(n)


# check if sun is being transformed
@persistent
def sun_handler(scene, depsgraph):  # allow rotating the sun and seeing changes in the real time
	gsettings = scene.general_settings
	asettings = scene.atmosphere_settings
	if gsettings.initialized:
		sun = get_object("Starlight Sun")
		if sun is None:
			return
		for update in depsgraph.updates:
			if update.id.original == sun and update.is_updated_transform:
				sun_calculation(bpy.context, depsgraph, 'realtime')
				throttle_azimuth_elevation_update(asettings)  # update az/el UI values


@persistent
def fog_handler(scene, depsgraph):
	gsettings = scene.general_settings
	if len(bpy.data.materials) > gsettings.material_count and gsettings.fog_enabled:
		gsettings.material_count = len(bpy.data.materials)
		toggle_fog(1)


# Render engine handler
previous_scene = None
@persistent
def frame_change_handler(scene, depsgraph):
	""" redraw atmosphere when scene has change """
	g = scene.general_settings
	sun = get_object("Starlight Sun")
	if sun is None:
		return

	global previous_scene
	if g.enabled and previous_scene != bpy.context.scene:
		# print('scene has changed')
		# redraw atmosphere
		sun_calculation(bpy.context, depsgraph, 'rendering')
		previous_scene = bpy.context.scene
		# reset default values to preset
		align_defaults_with_preset()

	# redraw atmosphere if between frames any of atmosphere UI parameters has changed
	a = scene.atmosphere_settings
	atmosphere_props = (
		a.azimuth, a.elevation, a.sun_diameter, a.sun_temperature, a.sun_intensity, a.sun_intensity,
		a.atmosphere_density, a.atmosphere_height, a.atmosphere_intensity, a.night_intensity, a.atmosphere_color,
		a.atmosphere_inscattering, a.atmosphere_extinction, a.atmosphere_mie, a.atmosphere_mie_dir, a.stars_intensity,
		a.stars_gamma, a.ground_albedo, a.ground_offset, a.atmosphere_distance, a.atmosphere_falloff,
		a.sun_radiance_gamma, sun.rotation_euler[0], sun.rotation_euler[2]
	)
	atmosphere_prop_strings = map(tuple_to_str, atmosphere_props)
	checksum = "".join(atmosphere_prop_strings)
	if g.enabled and g.all_props_checksum != checksum:  # redraw atmosphere only when a property has changed
		sun_calculation(bpy.context, depsgraph, 'rendering')
	g.all_props_checksum = checksum


@persistent
def blendfile_load_handler(scene, depsgraph):
	""" on blendfile load set preset default values """
	g = bpy.context.scene.general_settings
	if g.enabled:
		align_defaults_with_preset()


def get_classes():
	return (
		# WorldTab (WT) and ToolBar (TB) panels
		RIG_PT_PhysicalCloudsWT,
		RIG_PT_PhysicalCloudsTB,

		RIG_PT_StarlightAtmosphereWT,
		RIG_PT_StarlightAtmosphereTB,
		RIG_PT_SunWT,
		RIG_PT_SunTB,
		RIG_PT_BinarySunWT,
		RIG_PT_BinarySunTB,
		RIG_PT_AtmosphereWT,
		RIG_PT_AtmosphereTB,
		RIG_PT_StarsWT,
		RIG_PT_StarsTB,
		RIG_PT_GroundWT,
		RIG_PT_GroundTB,
		RIG_PT_ArtisticControlsWT,
		RIG_PT_ArtisticControlsTB,
	

		RIG_MT_Presets,
		RIG_OT_AddPreset,
		RIG_OT_ResetDefault,
		GeneralSettings,
		AtmosphereSettings,
		RIG_OT_OpenExpFeaturesPage,
		RIG_MT_addon_preferences
	)


def register():
	classes = get_classes()
	for cls in classes:
		bpy.utils.register_class(cls)
	bpy.types.Scene.general_settings = PointerProperty(type=GeneralSettings)
	bpy.types.Scene.atmosphere_settings = PointerProperty(type=AtmosphereSettings)

	# Depsgraph change handler
	bpy.app.handlers.depsgraph_update_post.append(sun_handler)
	bpy.app.handlers.depsgraph_update_post.append(fog_handler)
	# Frame change handler
	bpy.app.handlers.frame_change_post.append(frame_change_handler)
	# Blendfile handler
	bpy.app.handlers.load_post.append(blendfile_load_handler)

	prefs = bpy.context.preferences.addons['physical-starlight-atmosphere'].preferences
	update_toolbar_label(prefs, bpy.context)


def unregister():
	classes = get_classes()
	for cls in classes:
		bpy.utils.unregister_class(cls)
	del bpy.types.Scene.atmosphere_settings
	del bpy.types.Scene.general_settings

	bpy.app.handlers.load_post.remove(blendfile_load_handler)
	bpy.app.handlers.frame_change_post.remove(frame_change_handler)
	# Depsgraph change handler
	bpy.app.handlers.depsgraph_update_post.remove(fog_handler)
	bpy.app.handlers.depsgraph_update_post.remove(sun_handler)


if __name__ == "__main__":
	register()


loaded = True