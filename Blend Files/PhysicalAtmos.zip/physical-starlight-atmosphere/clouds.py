import bpy
from bpy.types import Panel
from . ui import DrawablePanel
from . sunlight import sun_calculation

# Draw UI

class PhysicalClouds(DrawablePanel):
    bl_label = "Physical Clouds"

    @classmethod
    def poll(self, context):
        prefs = context.preferences.addons['physical-starlight-atmosphere'].preferences
        if prefs.use_experimental_features:
            settings_available = context.scene and hasattr(context.scene, 'general_settings')
            if not settings_available:
                return False
            if self.bl_context == "objectmode" and not prefs.toolbar_enabled:
                return False
            return True
        else:
            return False

    def draw_header(self, context):
        if context.scene and hasattr(context.scene, 'general_settings'):
            settings = context.scene.general_settings
            layout = self.layout
            layout.prop(settings, 'clouds_enabled', text='')

    def draw(self, context):
        gsettings = context.scene.general_settings
        layout = self.layout
        layout.enabled = gsettings.clouds_enabled
        col = self.indentedColumn()
        col.prop(gsettings, 'clouds_scale')
        col.prop(gsettings, 'clouds_thickness')
        col.label(text='Coverage:')
        col.prop(gsettings, 'clouds_min')
        col.prop(gsettings, 'clouds_max')
        col.label(text='Lighting:')
        col.prop(gsettings, 'clouds_lighting_intensity')
        col.prop(gsettings, 'clouds_amount')
        col.prop(gsettings, 'clouds_power')
        row = col.row(align=True)
        row.label(text='Inscattering:')
        row.prop(gsettings, 'clouds_scattering')


class RIG_PT_PhysicalCloudsWT(Panel, PhysicalClouds):
    bl_idname = "RIG_PT_PhysicalCloudsWT"
    bl_region_type = "WINDOW"
    bl_space_type = "PROPERTIES"
    bl_context = "world"


class RIG_PT_PhysicalCloudsTB(Panel, PhysicalClouds):
    bl_idname = "RIG_PT_PhysicalCloudsTB"
    bl_region_type = "UI"
    bl_space_type = "VIEW_3D"
    bl_context = "objectmode"
    bl_category = "Clouds"


# UI checkbox handler
def toggle_clouds(self, context):
    gsettings = bpy.context.scene.general_settings

    if gsettings.clouds_enabled:
        link_clouds()
    else:
        unlink_clouds()
    depsgraph = bpy.context.evaluated_depsgraph_get()
    sun_calculation(bpy.context, depsgraph, 'rendering')

def clouds_update_handler(self, context):
    inputs = bpy.context.scene.world.node_tree.nodes["simple_clouds"].inputs
    inputs['Scale'].default_value = context.scene.general_settings.clouds_scale
    inputs['Min'].default_value = context.scene.general_settings.clouds_min
    inputs['Max'].default_value = context.scene.general_settings.clouds_max
    inputs['Thickness'].default_value = context.scene.general_settings.clouds_thickness
    inputs['Val1'].default_value = context.scene.general_settings.clouds_amount
    inputs['Val2'].default_value = context.scene.general_settings.clouds_power
    inputs['Scattering'].default_value = context.scene.general_settings.clouds_scattering
    inputs['Intensity'].default_value = context.scene.general_settings.clouds_lighting_intensity
    

def link_clouds(): 
    node_tree = bpy.context.scene.world.node_tree
    if 'simple_clouds' in node_tree.nodes:
        output = node_tree.nodes["simple_clouds"].outputs["Result"]
        input = node_tree.nodes["StarlightAtmosphere"].inputs["in_clouds"]
        node_tree.links.new(output, input)


def unlink_clouds():
    node_tree = bpy.context.scene.world.node_tree
    if 'simple_clouds' in node_tree.nodes:
        output = node_tree.nodes["simple_clouds"].outputs["Result"]
        input = node_tree.nodes["StarlightAtmosphere"].inputs["in_clouds"]
        for l in output.links :
            if l.to_socket == input :
                node_tree.links.remove(l)
    